/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2018 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "can.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "bsp_key.h"
#include "bsp_led.h"
#include "bsp_can.h"
#include "bsp_pwm.h"
#include "pid.h"
#include "kaerman.h" 
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
#define voltage_compensation 10 //���ٶ�pid�˲�ֵ��Ĳ����趨ֵ

uint8_t circle_flag;//��Ȧ��¼��Ȧ������
extern moto_info_t motor_info[MOTOR_MAX_NUM];//�����Ϣ�ṹ��
int16_t led_cnt;
int16_t real_speed;
uint16_t real_ecd;
float real_current;
//����pid�ṹ��
pid_struct_t speed_motor_pid[1];
pid_struct_t ecd_motor_pid[1];
//�����ṹ��
pid_struct_t Cascade_speed_motor_pid[1];
pid_struct_t Cascade_ecd_motor_pid[1];

//Ŀ���������
float target_speed;//ԭ���ٶ�Ŀ��ֵ
float target_speed2;//��ֵ�ٶ�Ŀ��ֵ
float target_ecd;//������Ŀ��ֵ
float turque_get;
float turque_set;
float current_set;//Ť��תΪ��������趨ֵ
float test_data[3];//��������
float alpha;//һ�׵�ͨ�˲�Ȩ�ز���
uint8_t tail[4] = {0x00, 0x00, 0x80, 0x7f};//vofa���ε����跢��tail
int32_t my_ecd;
int32_t my_speed;
int32_t last_my_speed;
uint8_t select_num;//pidģʽѡ�����
uint16_t pwm_set=1550;
uint16_t pwm_angle;


//�������ṹ�嶨��//
KalmanFilter kaer;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_CAN1_Init();
  MX_TIM1_Init();
  MX_USART2_UART_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
	HAL_GPIO_WritePin(GPIOH, POWER1_CTRL_Pin|POWER2_CTRL_Pin|POWER3_CTRL_Pin|POWER4_CTRL_Pin, GPIO_PIN_SET); 
	pwm_init();
	//��cubmax��ʼ��//
	my_init();
	//��ʼֵ�趨//
  Initial_value_setting();
 
  //����ʱ�ٶ���Ƕȵķֱ������ʼ��//
  pid_init(&speed_motor_pid[0], 24.5, 0.1, 60, 230, 14000); //�п����� 24.5 0.1 60 230 14000
  pid_init(&ecd_motor_pid[0], 12.3, 0.0025, 30, 300, 14000);//4 0.002 30 200 14000 
  //pid_init(&torque_motor_pid[0], 0, 0, 0, 14000, 14000);//�����ͨ����λ��ֱ�ӵ�������
  //***********END******************//
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */
	//��ѭ����������￪ʼд//
  //Ť��ת����//
	Torque_to_current();
	//�ٶȻ����������˲�//
	Kalman_and_low_pass_fliter();
	//pid����(Ŀǰ���ǵ���)
	Individual_PID_selection();
	//���͵���can�ź�//
  set_motor_voltage(0,motor_info[0].set_voltage,0,0,0);
	//��Ȧ��¼//
  gimbal_ecd_count();
	//���ڽ���//
	HAL_UART_Receive_IT(&huart2,re_data, 3);
	//���ε��Ժ���//
  //	vofa_test(target_ecd,motor_info[0].ecd_out);
  //pwm����//
  //  __HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_1, pwm_set);
  //	__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_2, pwm_set);
  //  __HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_3, pwm_set);
  //  __HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_4, pwm_set);
	HAL_Delay(1);
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 6;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
//***********my functions***********//

/**
  * @name  real_traget
  * @brief �������ڲ�����һ�׵�ͨ�˲�����ʧ���ٶ�ֵ
  * @retval None
  */

float real_traget(void)
{
  // if (target_speed>=0)      target_speed2=target_speed+7;
  // else if (target_speed<0)  target_speed2=target_speed-7;
  // else if(target_speed==0)  target_speed2=0;
	target_speed2=target_speed;
  return target_speed2;
}

/**
  * @name  gimbal_ecd_count
  * @brief ��������ֵ��չΪ��Ȧ����0-8191
  * @retval None
  */

void gimbal_ecd_count(void)
{
  if(circle_flag==0)
   {
  motor_info[0].ecd0 =motor_info[0].rotor_angle;
	circle_flag=1;
   }
	if(circle_flag==1)
	{
	motor_info[0].ecd_now = (float) motor_info[0].rotor_angle;
  if((motor_info[0].ecd_now -motor_info[0].ecd_last)< -4096)
	{
	motor_info[0].ecd_round++;
	}
	if((motor_info[0].ecd_now -motor_info[0].ecd_last)> 4096)
	{
	motor_info[0].ecd_round--;
	}
	if(motor_info[0].ecd_round == 0)
	{
	motor_info[0].ecd_out= (float)((motor_info[0].rotor_angle));
	}
	if(motor_info[0].ecd_round >=1)
	{
	motor_info[0].ecd_out = (float)(((motor_info[0].ecd_round-1) *8191  + motor_info[0].rotor_angle));
	}
	if(motor_info[0].ecd_round <= (-1))
	{
	motor_info[0].ecd_out =(float)(((motor_info[0].ecd_round +1)* 8191  + (-8191 + motor_info[0].rotor_angle)));
	}
	my_ecd=motor_info[0].ecd_out;
	motor_info[0].ecd_last = motor_info[0].ecd_now;	
	} 	
}

/**
  * @name  Initial_value_setting
  * @brief �����ĳ�ʼֵ�趨
  * @retval None
  */
void Initial_value_setting(void)
{
  target_ecd=1000;//Ŀ��Ƕȣ�������ֵ��
  turque_set=0.04;//Ŀ��Ť��
	target_speed=30;//Ŀ���ٶȣ����ھ����˲����ٶ���ֵ��Ϊʧ�棬���޷��������嵥λ��
	alpha=0.24;//��ͨ�˲���ռ�Ȳ���
	select_num=2;//pidģʽѡ��
}

/**
  * @name  my_init
  * @brief ���ú����ĳ�ʼ��
  * @retval None
  */

void my_init(void)
{
	//������ʱ��//
//  HAL_TIM_Base_Start_IT(&htim1);
	HAL_TIM_Base_Start_IT(&htim2);
	//��������ʼ��
	Kalman_Init(&kaer);
	//switch on 24v power
  HAL_GPIO_WritePin(GPIOH, POWER1_CTRL_Pin|POWER2_CTRL_Pin|POWER3_CTRL_Pin|POWER4_CTRL_Pin, GPIO_PIN_SET); 
  //can�˲�����ʼ��//	
  can_user_init(&hcan1);
}

/**
  * @name  Torque_to_current
  * @brief Ť��ֵת��Ϊ����ֵ
  * @retval None
  */
void Torque_to_current(void)
{
  //0.741ΪŤ�س�����3��16384�ֱ����������ADC�Ķ�Ӧ��ϵ��3A��14bit��
  current_set=turque_set/0.741/3*16384;
}

/**
  * @name  Kalman_and_low_pass_fliter
  * @brief �Ե�������ٶȵĿ������͵�ͨ�˲�
  * @retval None
  */

void Kalman_and_low_pass_fliter(void)
{
  Kalman_Update(&kaer,motor_info[0].rotor_speed);
//  kaer.x[0]=alpha*kaer.x[0]+(1-alpha)*kaer.last_x[0];
//  kaer.last_x[0]=kaer.x[0];	
}

/**
  * @name  Individual_PID_selection
  * @brief ѡ��pid����ģʽ
  * ����select_num:1->�ٶȵ��� 2->�Ƕȵ��� 3->�Ƕȴ���
  * @retval None
  */

void Individual_PID_selection(void)
{
	switch(select_num)
	{
	case 1:
	motor_info[0].set_voltage = pid_speed_calc(&speed_motor_pid[0],real_traget(), kaer.x[0]);
	break;
	case 2:
	motor_info[0].set_voltage = pid_calc(&ecd_motor_pid[0], target_ecd, motor_info[0].ecd_out);
	break;
	case 3:
	motor_info[0].set_speed = pid_calc(&Cascade_ecd_motor_pid[0], target_ecd, motor_info[0].ecd_out);
	motor_info[0].set_voltage = pid_speed_calc(&Cascade_speed_motor_pid[0],motor_info[0].set_speed, kaer.x[0]);
  break;
	}
}

/**
  * @name  vofa_test
  * @brief ����vofa+�Ĳ��ε���
  * �˴�������usart2,���������Ӵ��ڣ��������λ�����õ�һ�����ڣ�
  * @retval None
  */

void vofa_test(float a,float b,float c)
{
  //���鸳ֵ//		
	test_data[0]=a;
  test_data[1]=b;
  
	//���´��ڷ���Ϊvofa���ԣ���Ҫʱ����ע��//
  HAL_UART_Transmit(&huart2,(uint8_t*)test_data,sizeof(test_data),10);
  HAL_UART_Transmit(&huart2,tail,sizeof(tail),10);
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
