#include "kaerman.h"  

#define DIM 1 // 状态维度  

// 初始化卡尔曼滤波器  
void Kalman_Init(KalmanFilter *kf) {  
    // 状态初始值  
    kf->x[0] = 0;  
    // 协方差初始值  
    kf->P[0][0] = 1;  

    // 状态转移矩阵  
    kf->F[0][0] = 1;  
    // 观测矩阵  
    kf->H[0][0] = 1;  
    // 过程噪声协方差  
    kf->Q[0][0] = 0.01;  
    // 测量噪声协方差  
    kf->R[0][0] = 0.1;  
}  

// 执行卡尔曼滤波  
void Kalman_Update(KalmanFilter *kf, float z) {  
    // 状态预测  
    float x_pred[DIM];  
    x_pred[0] = kf->F[0][0] * kf->x[0];  

    // 协方差预测  
    float P_pred[DIM][DIM];  
    P_pred[0][0] = kf->F[0][0] * kf->P[0][0] * kf->F[0][0] + kf->Q[0][0];  

    // 计算卡尔曼增益  
    float S = P_pred[0][0] * kf->H[0][0] + kf->R[0][0]; // 预测测量的误差  
    float K = P_pred[0][0] * kf->H[0][0] / S; // 卡尔曼增益  

    // 状态更新  
    kf->x[0] = x_pred[0] + K * (z - (kf->H[0][0] * x_pred[0]));  

    // 协方差更新  
    kf->P[0][0] = (1 - K * kf->H[0][0]) * P_pred[0][0];  
}  